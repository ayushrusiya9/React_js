
const Rhome = () =>{



    return (
      <div>
        <h1>Rhome</h1>
      </div>
    )
}

export default Rhome
